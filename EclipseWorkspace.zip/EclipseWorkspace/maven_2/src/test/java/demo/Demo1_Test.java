package demo;

import org.testng.annotations.Test;

public class Demo1_Test {

	
	@Test
	public void Deskphone(){
		
		System.out.println("Deskphone test");
		
	}
	
	@Test
	public void Euro(){
		
		System.out.println("Euro test");
		
	}
}

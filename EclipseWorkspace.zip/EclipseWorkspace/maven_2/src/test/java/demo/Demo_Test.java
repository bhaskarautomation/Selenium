package demo;

import org.testng.annotations.Test;

public class Demo_Test {

	@Test
	public void mobile(){
		
		System.out.println("Mobile test");
		
	}
	
	@Test
	public void Rupee(){
		
		System.out.println("Rupee test");
		
	}
	
	
	
}

package exceptions_in_java;

import java.util.InputMismatchException;
import java.util.Scanner;

// CNTRL+ LEFT CLICK is used to find the required method location in the entire program
//Stack trace and call stack

public class exception {

	public static void main(String[] args) {
			
	
	int x = getin();
	int y = getin();
		
	Div(x,y);	
		
	System.out.println("Division is "+Div(x,y));	
		
		

	}
	private static int getin(){
		
	Scanner s = new Scanner(System.in);
	System.out.println("Please enter a number");
	//return s.nextInt();
	try{
	return s.nextInt();
	}
	catch(InputMismatchException e){
	e.printStackTrace();	
	return 0;
	}
	}
    private static int Div(int x,int y){
    	
    	try{
    	return	x/y;
    		}
    	catch(Exception e){
    		return 0;
    	//Arithmetic
    	}
    	
    }
}

package test;

import org.testng.annotations.Test;

public class Day2 {

	
		@Test
		public void hello(){
			
			System.out.println("Welcome to TESTNG 2");
			
		} 
		
		@Test
		public void bye(){
			
			System.out.println("Bye Bye 2");
		}
	
}


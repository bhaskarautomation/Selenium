package test;

import org.testng.annotations.Test;
@Test
public class Day1 {

	
	
	//@Test
	public void hello(){
		
		System.out.println("Welcome to TESTNG");
		
	} 
	
	//@Test
	public void bye(){
		
		System.out.println("Bye Bye");
	}
}

package page.crm.qa.pages;

public class HomePage {

}

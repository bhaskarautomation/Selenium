package page.crm.qa.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import page.crm.qa.base.Testbase;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;


public class TestUtil extends Testbase{

	public static long PAGE_LOAD_TIMEOUT = 20;
	public static long IMPLICIT_WAIT =10;
	
    
	
	static Sheet sheet;
	static Workbook book;
	static Row row;
	static Cell cell;
	
	public static String TESTDATA_SHEETPATH = "C:\\Users\\AG18664\\EclipseWorkspace\\"
			+ "pageobject_datadrivenn\\src\\main\\java\\page\\crm\\qa\\testdata\\Inputdata.xlsx";
	
	public static void screenshot(String methodname){
		
		 File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		 try {
			FileUtils.copyFile(srcFile, new File("C:\\Users\\AG18664\\EclipseWorkspace"
					+ "\\Screenshot_Testng Listeners\\screenshot\\" +methodname+".jpg"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}
	public Object[][] readData(String SheetName) {
	
		
	    FileInputStream file = null;	
		
	    try {
			
	    	file = new FileInputStream(TESTDATA_SHEETPATH);
	    	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		try {
			
			book = WorkbookFactory.create(file);
			
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		sheet = book.getSheet(SheetName);
		
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		
		for(int i=0;i<sheet.getLastRowNum();i++){
			
			// System.out.println(sheet.getLastRowNum() + "--------" +
			// sheet.getRow(0).getLastCellNum());
			
			for(int j=0;j<sheet.getRow(0).getLastCellNum();j++){
			
				data[i][j]=	sheet.getRow(i+1).getCell(j).toString();
				
				// System.out.println(data[i][k]);
			}
		}
		return data;   
	}
	
	
	
}

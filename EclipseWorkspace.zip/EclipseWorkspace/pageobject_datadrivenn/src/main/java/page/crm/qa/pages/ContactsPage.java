package page.crm.qa.pages;

public class ContactsPage {

}

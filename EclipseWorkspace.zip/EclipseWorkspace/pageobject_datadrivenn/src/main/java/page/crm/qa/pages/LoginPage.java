package page.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import page.crm.qa.base.Testbase;

public class LoginPage extends Testbase {

	
	//OR - Object Repository 
	//Page Factory
	
	@FindBy(name = "email")public WebElement email;
	
	//@FindBy(how = How.NAME,using ="email") public WebElement mail;
	
	@FindBy(name = "password")public WebElement password;
	
	
	@FindBy(xpath = "//*[@id='ui']/div/div/form/div/div[3]") public WebElement Loginbutton;
	
	@FindBy(linkText= "Sign Up") public WebElement Signupbutton;
	
	
	/*
	 * Here we have defined the webelements using @FindBy
	 * In order to initialize the webelements, we have to use the below.
	 * PageFactory.initElements(driver, this);
	 * 
	 * PageFactory is class
	 * initElements --will initialize the webelements
	 * driver -driver from base class
	 * this -- means all the webelements/variable in the present class LoginPage
	 * 
	 */
	
	//constructor
	public LoginPage(){
	PageFactory.initElements(driver, this);
		
	}
	
	
	public String ValidateTitlepage(){
		
		return driver.getTitle();
	}
	
	public HomePage login(String em,String pwd)
	{
		email.sendKeys(em);
		password.sendKeys(pwd);
		Loginbutton.click();
		
		return new HomePage();
		
	}
	
	
}

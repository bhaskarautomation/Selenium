package page.crm.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import page.crm.qa.base.Testbase;
import page.crm.qa.pages.LoginPage;
import page.crm.qa.utilities.TestUtil;

public class LoginPageTest extends Testbase{
	
	LoginPage loginpage;
	
	TestUtil testutil = new TestUtil();
	
	String SheetName = "Contracts";
	
	public LoginPageTest(){
		super();//Super keyword will call Testbase class constructor
	}
	
		
	@BeforeTest
	public void SetUp(){
		
		initilization();
		loginpage = new LoginPage(); //This line will call the constructor of class LoginPage()
		
			
	}
	
	
	@Test(priority = 1)
	public void LoginpageTitleTest(){
		String title = loginpage.ValidateTitlepage();
		Assert.assertEquals(title, "CRM");

		
	}
	
	@DataProvider
	public Object[][] Getdata(){
		
		Object data[][] = testutil.readData(SheetName);
		return data;
		
	}
	
	@Test(priority = 2,dataProvider ="Getdata")
	public void LoginTest(String Title,String Firstname,String lastname,String Middlename){
		//loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		
		System.out.println("Title "+Title+"Firstname is "+Firstname+"LastName is "+lastname+"Middlename is "+Middlename);
		
		
	}
	

//	@AfterTest
//	public void tearDown(){
//		driver.quit();
//		
//	}
	
	
	
	
}

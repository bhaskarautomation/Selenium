package ackage;

public class main {

	public static void main(String[] args) {
		
	Gearbox bmw = new Gearbox(6);
	//the inner class cannot be directly instantiated like Gear first = new Gear(1,12.3);
	//We have to specify the outerclass "Gearbox" and instantiate the inner class "Gear" like below
	Gearbox.Gear first = bmw.new Gear(1,12.3);	
	//System.out.println(first.driveSpeed(1000));
	//The code in the line 7th and 10th can be written as below
	Gearbox.Gear second = new Gearbox(6).new Gear(5,1.2);
	
	
	
	}

}

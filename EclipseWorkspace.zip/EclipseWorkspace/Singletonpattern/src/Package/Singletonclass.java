package Package;

public class Singletonclass {

	public static void main(String[] args) {
		
		//In OOP,Singleton class is a class that can have only one object(instance of the class) at a time.
		//How to design singleton class
		//1.make constructor as private
		//2.write a static method that has return type of object of this singleton class(Lazy)
		
	}

}

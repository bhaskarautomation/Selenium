package qaclickacademy;

import org.testng.annotations.Test;

public class Appium_Test {

	
	   @Test
	    public void Nativeandriodapp(){
	    	
	    	System.out.println("Nativeandriodapp");
	    	
	    }
	    @Test
	    public void IOSapp(){
	    	
	    	System.out.println("IOSapp");
	    	
	    }
	
}

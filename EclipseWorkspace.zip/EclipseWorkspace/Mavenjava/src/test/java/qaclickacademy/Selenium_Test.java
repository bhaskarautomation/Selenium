package qaclickacademy;

import org.testng.annotations.Test;

public class Selenium_Test {

    @Test
    public void Browserautomation(){
    	
    	System.out.println("Browserautomation");
    	
    }
    @Test
    public void ElementsUi(){
    	
    	System.out.println("ElementsUi");
    	
    }
}

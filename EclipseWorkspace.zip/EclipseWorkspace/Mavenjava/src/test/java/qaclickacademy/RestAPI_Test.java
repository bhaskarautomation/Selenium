package qaclickacademy;

import org.testng.annotations.Test;

public class RestAPI_Test {

	
	   @Test
	    public void postJira(){
	    	
	    	System.out.println("postJira");
	    	
	    }
	    @Test
	    public void Deletetwitter(){
	    	
	    	System.out.println("Deletetwitter");
	    	
	    }
	
}

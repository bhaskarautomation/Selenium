package codingchallenge;

public class Leftrotation_array {

	public static void main(String[] args) {


		int[] intarray=  new int[5];
		
		for(int i=0;i<intarray.length;i++)
		{		
			intarray[i]= i;			
			System.out.println(intarray[i]);
			
		}
		
      	System.out.println("-----------");
	    
      	intarray= leftrotation(intarray,2);
      	
      	for(int i=0;i<intarray.length;i++)
		{	System.out.println(intarray[i]);
							
		}
		
		
	}

	public static int[] leftrotation(int[] arr,int n){
		
		for(int j=0;j<n;j++){
		
		int temp = arr[0];
		
		for(int i=0;i<arr.length-1;i++){
			
			arr[i]= arr[i+1];
					
		}
		arr[arr.length-1]= temp;
		}
		
		return arr;
	}
	
	
}

package codingchallenge;

public class String_array {

	public static void main(String[] args) {
	  
		int size = 4;
		
		String[] Sarray = new String[size];
		
		for(int i=0;i<size;i++){
			
			Sarray[i]= "This contains "+i;
			
			System.out.println(Sarray[i]);
			
		}
		
	}

}

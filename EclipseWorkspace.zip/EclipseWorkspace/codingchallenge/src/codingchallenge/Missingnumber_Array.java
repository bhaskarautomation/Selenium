package codingchallenge;

import java.util.Arrays;

public class Missingnumber_Array {

	public static void main(String[] args) {
		 
		int[] arr= {4,3,1,2};
		//Arrays.sort(arr);
		
		for(int i:arr){
			
			System.out.println(i);	
		}
		
		
		int sum= 0,sum1=0;
		for(int i=0;i<4;i++){
			sum = sum+arr[i];
			System.out.println(arr[i]);	
		
		}
		
		System.out.println("-------------");
		for(int i=1;i<=5;i++){
			
			sum1 = sum1+i;
				
		}
		
		System.out.println(sum1-sum);
		//System.out.println(sum);
	}

}

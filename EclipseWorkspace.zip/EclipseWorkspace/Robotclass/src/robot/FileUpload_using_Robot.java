package robot;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class FileUpload_using_Robot {

	
	public void Fileupload(String Path) throws AWTException{
		
		StringSelection str = new StringSelection(Path);
		
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		
		clipboard.setContents(str, null);
		
		Robot robot = new Robot();
		
		robot.delay(150);
		
		robot.keyPress(KeyEvent.VK_F);
		
	}
}


package Java_Generics;

import java.util.ArrayList;

//CNTRL + F11  >>> To run the code

public class Main {

	public static void main(String[] args) {
	
		//The below ArrayList is raw type.References to the generic type<E> should be parameterized as shown in line 14.
		//ArrayList item = new ArrayList();
		
		ArrayList <Integer>items = new ArrayList<Integer>();
		
		//The above line can be written as like ArrayList <Integer>items = new ArrayList<>();		
		
		items.add(1);
		items.add(2);
		items.add(3);
		Printitems(items);
			
		//The above line is static reference type.If we remove the static keyword in the below method,
		//we will get compile error "Cannot make a static reference to the non-static method Printitems(ArrayList<Integer>) from the type Main"
		
	}
   private static void Printitems(ArrayList<Integer> n){
	   
	   for(Object i : n){
		   
		   System.out.println("Items are "+ (Integer)i*3);
		   
//     The above can be written as below also	   
//		 for(Integer i : n){
//		 System.out.println("Items are "+ i*3);
//		  
		   
//		  or we can write like below also since Java automatically does the autoboxing and unboxing
//			 for(int i : n){
//			 System.out.println("Items are "+ i*3);
//		      
	   }
	   
	   
   }
}

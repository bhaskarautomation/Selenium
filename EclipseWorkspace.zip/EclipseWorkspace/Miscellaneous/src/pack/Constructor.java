package pack;

class bmp{
	
	int c =20;
	
	bmp(){
		
	int b =10;	
		System.out.println("This is superclass");
	}


}

class imp extends bmp{
	 	
	void methd(){
		
		
		
	}
	
}

public class Constructor {

	public static void main(String[] args) {

	imp a = new imp();
      
           
	}
	
	
	
//	
}

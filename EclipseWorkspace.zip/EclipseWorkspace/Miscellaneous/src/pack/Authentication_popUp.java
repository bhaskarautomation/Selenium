package pack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Authentication_popUp {

	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", "C://Java learning//Selenium//Drivers//chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://admin:admin@the-internet.herokuapp.com/basic_auth");
		
		// admin:admin --->the first "admin" is username and 2nd one "admin" is the password
		//website : http://the-internet.herokuapp.com/basic_auth
		//The Selenium will enter the user name and password and then clik on the sign in button if we 
		//pass the line 15
		

	}

}

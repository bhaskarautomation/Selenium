package pack;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Javascript_popups {

	public static void main(String[] args) throws InterruptedException {
		
		
        System.setProperty("webdriver.chrome.driver", "C://Java learning//Selenium//Drivers//chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		
		Thread.sleep(2000);//script will pause for 2000 ms.
		
		Alert alert = driver.switchTo().alert();
		
		String text= alert.getText();//To get alert text
		
	   if(text.equals("Please enter a valid user name"))
	   {
		alert.accept();// Click on Ok button
		System.out.println("correct alert msg");
	   }
	   else
	   {
		   System.out.println("Incorrect alert msg");
		   
	   }
	   
		//alert.dismiss();// click on Cancel button
		 
	   WebElement Day = driver.findElement(By.xpath(""));
	   Select select = new Select(Day);
	   
	   select.getOptions();
	   
		
	}

	
	
	
}

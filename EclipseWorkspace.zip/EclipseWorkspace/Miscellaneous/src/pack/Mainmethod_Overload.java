package pack;

public class Mainmethod_Overload {

	//JVM will try to search for main method with parameters like String array i.e String[] args
	
	public static void main(String[] args) {
			
		System.out.println("Main method");
	
		main("bhaskar");
		main(4);
		main(2,3);
	
	}
	
	public static void main(String args){
		
		System.out.println("overloaded main method 1");
	}

	public static void main(int a){
		
		System.out.println("overloaded main method 2");
	}
	
    public static void main(int a,int b){
		
		System.out.println("overloaded main method 3");
	}
	
    
}

package pack;

public class B {

	public static void main(String[] args) {
		
		System.out.println("B--Main method");
		A.main(args);//the line will call the main method of class A
	}

}

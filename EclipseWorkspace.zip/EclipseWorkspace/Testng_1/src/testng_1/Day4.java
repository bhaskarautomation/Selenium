package testng_1;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day4 {
  
	@Test
	public void day4method1(){
		
		System.out.println("this is first method");
		
		//The below line will fail the day4method1 test.
		Assert.assertTrue(false);
		
	}
	
	@Test
	public void day4method2(){
		
		System.out.println("this is second method");
		
		
	}
    
	@Test
    public void day4method3(){
		
		System.out.println("this is third method in Day4");
	}
	
   
}

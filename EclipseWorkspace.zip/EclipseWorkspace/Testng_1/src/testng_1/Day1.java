package testng_1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day1 {
	
	@Test(groups =("Smoke"))
	public void method1(){
		
		System.out.println("this is first methodin Day1");
	}
	@BeforeTest
	public void method2(){
		
		System.out.println("this is second method");
		
	}
	
	@Parameters({"URL"})
    @Test
	public void method3(String url){
		
		System.out.println("this is third method in Day1");
		System.out.println("the website is "+url);
		
		
	}
	@AfterTest
	public void method4(){
		
		System.out.println("this is fourth method");
	}
}

package testng_1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day2 {
    
	@Parameters({"URL","Userid"})
	@Test
	public void day2method1(String url,String userid){
		
		System.out.println("this is first method");
		System.out.println(url);
		System.out.println(userid);
	}
	
	@BeforeTest
	public void day2method2(){
		
		System.out.println("this is second method");
		
	}
    @Test(groups=("Smoke"))
	public void day2method3(){
		
		System.out.println("this is third method in Day2");
	}
	@AfterTest
	public void day2method4(){
		
		System.out.println("this is fourth method");
	}
	
	
}

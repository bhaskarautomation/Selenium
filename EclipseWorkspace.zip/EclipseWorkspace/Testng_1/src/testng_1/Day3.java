package testng_1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day3 {
  
	
	
	@Test(dataProvider = "getdata")
	public void day3method2(String username, String password){
		
		System.out.println("this is second method");
		System.out.println(username);
		System.out.println(password);
		
	}
    
	@Test(groups=("Smoke"))
    public void day3method3(){
		
		System.out.println("this is third method in Day3");
	}
	
    @DataProvider
	public Object[][] getdata(){
	
    	//1st combination --username password -goodcredit history
    	//2nd combination -- username password -No credit history
    	//3rd -- username password -bad credit history
    	
    	
    	Object[][] data = new Object[3][2];
    	
    	//1st set 
    	data[0][0] = "firstusername";
    	data[0][1] = "firstpassword";
    	
    	//2nd set 
    	data[1][0] = "secondusername";
    	data[1][1] = "secondpassword";
        
    	//3rd set
       	data[2][0] = "thirdusername";
    	data[2][1] = "thirdpassword";
    	
    	return data;
		
	}
	
	
}

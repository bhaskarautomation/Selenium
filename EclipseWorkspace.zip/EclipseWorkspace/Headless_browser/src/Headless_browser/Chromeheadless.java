package Headless_browser;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Chromeheadless {

	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", "C://Java learning//Selenium//Drivers//chromedriver.exe");

				
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("window-size=1400,800");
		
		options.addArguments("headless");
		
		WebDriver driver = new ChromeDriver(options);
		
		driver.get("https://www.facebook.com/");
		
		//"https://www.facebook.com/"
		
		System.out.println(driver.getTitle());
		
	//List<WebElement> a = driver.findElements(By.xpath(""));
		
		
	}

}

package Headless_browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class Firefoxheadless {

	public static void main(String[] args) {
	
		/* FirefoxBinary and FirefoxOptions are the two classes used for Headless firefoxbrowser
		 * If you run the below code,without opening the firefox browser,the code will get executed in background
		 *
		 */
		
		FirefoxBinary firefoxbinary = new FirefoxBinary();
		
		firefoxbinary.addCommandLineOptions("--headless"); 
		
		System.setProperty("Webdriver.gecko.driver", "C://Java learning//Selenium//Drivers//geckodriver.exe");
		
		FirefoxOptions fo = new FirefoxOptions();
		
		fo.setBinary(firefoxbinary);
		
		WebDriver driver = new FirefoxDriver(fo);
		
		driver.get("https://www.facebook.com/");
		
		driver.getTitle();
		
		
		
		

		
		
	}

}

package TestNG_listeners.Maven_Screenshot;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(CustomListener.class)
public class ScreenshotTest extends Base{

	@BeforeTest
	public void Setup(){
		
	initilization();
		
	}
	
	@AfterTest
	public void quit(){
		
		driver.quit();
		
	}
	
	@Test
	public void method1(){
		Assert.assertEquals(true, true);
		
	}
	
	@Test
	public void method2(){
		Assert.assertEquals(false, true);
		
	}
	@Test
	public void method3(){
		Assert.assertEquals(true, true);
		
	}
}

package Package;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class broken_links_images_webpage {

	public static void main(String[] args) throws MalformedURLException, IOException {
		
		System.setProperty("webdriver.chrome.driver", "C://New Folder//Java learning//Selenium//Drivers//chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("https://freecrm.com/");
		
		//driver.findElement(By.tagName(""));
		
		List<WebElement> links= driver.findElements(By.tagName("a"));//anchor tag for links
		
		links.addAll(driver.findElements(By.tagName("img")));//tag for images.this step will add the image links to the links list array.
		
		System.out.println("The total no of links is "+links.size());
		
		List<WebElement> activelinks = new ArrayList<WebElement>();
		
		//code to get the links which have only href attributes.Some anchor tags may not have href attributes i.e no links 
		//Some href attributes will contains javascript instead of like this " https://www.xyz.com".
		//href which contain Javascript are not valid links in webpage.
		
		for(int i=0;i<links.size();i++)
		{
			if(links.get(i).getAttribute("href")!=null && (! links.get(i).getAttribute("href").contains("Javascript"))){
				
				activelinks.add(links.get(i));
				
		}
			
				
			
		}
		System.out.println("The total no of active links and images is "+activelinks.size());
		
		//check the href url,with HttpURLConnection API
		//200 -- ok
		//400 -- Not found
		//500 -- Internal error
		//400 -- bad request
				
		for(int j=0;j<activelinks.size();j++){
		
		HttpURLConnection connection= (HttpURLConnection)new URL(activelinks.get(j).getAttribute("href")).openConnection();
		
		connection.connect();
		
		String Response= connection.getResponseMessage();
		
		connection.disconnect();
		
		System.out.println(activelinks.get(j).getAttribute("href")+"---->"+Response);
		
		}	
		
		
		

	}

}

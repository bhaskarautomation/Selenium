package helllo;

import java.util.Scanner;

//Program to find the Minimum value of an array 


public class Minvalue_Array {
	
    //To read/scan data from console,below Scanner class will be used.
	
	private static Scanner scanner = new  Scanner(System.in);
	
    public static void main(String[] args) {
		
		System.out.println("Enter count");
		
		//Scans the next token of the input as an int.
		int count = scanner.nextInt();
		//
		scanner.nextLine();
		
				
		int[] referencedarray = readIntegers(count);
		int Minvalue = findMin(referencedarray);
  	    System.out.println("Min value is "+Minvalue);
		
	}
	
	private static int[] readIntegers(int count){
		
		int[] array = new int[count];
        for(int i=0;i<array.length;i++)
        {
        	System.out.println("Enter a number");
        	int number  = scanner.nextInt();
        	array[i] = number;     	
        	
        }
        return array;
	}
    private static int findMin(int[] array){
		
    	int min = Integer.MAX_VALUE;
    	
    	for(int i=0;i<array.length;i++)
    	{
    	   if(array[i]<min)
    	   {
    		min = array[i];
    	   }
    	}
    	return min;
    	
    	
    	
    	
    }
}


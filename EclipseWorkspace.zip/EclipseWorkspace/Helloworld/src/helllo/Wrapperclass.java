package helllo;

import java.util.ArrayList;

public class Wrapperclass {

	public static void main(String[] args) {
		
		
		String[] strArray = new String[10];
		
		int[] intArray = new int[10];
		
		
		ArrayList<String> strArraylist = new ArrayList<String>();
		
	//We can't do like the below.The error is because int is primitive type but String is class
    //	so we need to use wrapper class for the corresponding primitive types	
	//ArrayList<int> intArraylist = new ArrayList<int>();
		
		Integer integer = new Integer(10);
		
		Double doublevalue = new Double(55.22);
		
		//Autoboxing
		
		Integer integerv =10;//Integer.valueOf(10)
		
		
		//Auto unboxing
		
		int a =integerv;//integerv.intValue();
		
		
		//ArrayList

        /* Here we are creating a list 
          of elements of Integer type. 
          adding the int primitives type values */
		
		ArrayList<Integer> intArraylist = new ArrayList<Integer>();
		
		for(int i=0;i<=10;i++){
			
			intArraylist.add(i);//intArraylist.add(Integer.valueOf(i));      
		}
		
		/*
		 * In above example we have created a list of elements of Integer type.
		 * We are adding int primitive type values instead of Integer Object and 
		 * the code successfully compiled. It does not generate a compile time error
		 * as java compiler create Integer wrapper Object from primitive int i and adds it to the list.
           See the following example for, How it converts�
		 *  
		 */
		
		   ArrayList<Integer> list = new ArrayList<Integer>(); 
	        for (int i = 0; i < 10; i++) 
	            list.add(Integer.valueOf(i)); 
	        
	      //Print the values 
		
        for(int i=0;i<=10;i++){
			
			System.out.println(intArraylist.get(i));
		
			
        }
		
		
		

	}

}

package helllo;

import java.util.Arrays;


//Program to print the array in reverse
//Input: Array is [1, 2, 3, 4, 5]
//Output: Array is [5, 4, 3, 2, 1]


public class Reversearray {

	public static void main(String[] args) {
		
		int[] array = {1,2,3,4,5};
		
		System.out.println("Array is "+Arrays.toString(array));
		
		Reversearray(array);
		
		System.out.println("Array is "+Arrays.toString(array));
		
		

	}
private static void Reversearray(int[] array){
	
	int Maxindex = array.length-1;
		
	int halflength = Maxindex/2;
	
	for(int i= 0;i<=halflength;i++)
	{
		int temp =array[i];
		
		array[i]= array[Maxindex-i];
		
		array[Maxindex-i] =temp;
		
		
	}
	
	
	
	
	
}
	
	
	
}

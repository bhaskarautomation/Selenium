package helllo;

import java.util.ArrayList;

//Program to use the ArrayList of string type


public class Grocerylist {

	private ArrayList<String> grocerylist = new ArrayList<String>();
	

	
	
	public void addGroceryItem(String item)
	{
		grocerylist.add(item);
		
	}
	public void printGrocerylist(){
		
		System.out.println("You have "+grocerylist.size()+" items in your grocery list");
		
		for(int i=0;i<grocerylist.size();i++){
			
			System.out.println((i+1)+"." +grocerylist.get(i));
		}
		
		
		
		
	}
	
	public void modifygroceryitem(int position,String newitem)
	{
		
		grocerylist.set(position, newitem);
		System.out.println("Grocery item "+(position+1)+" has been modified");
		
		
	}	
	public void removegroceryitem(int position){
		
		grocerylist.remove(position);
		System.out.println();
		
		
	}
	 public String findItem(String searchItem) {
//       boolean exists = groceryList.contains(searchItem);

       int position = grocerylist.indexOf(searchItem);
       if(position >=0) {
           return grocerylist.get(position);
       }

       return null;
   }
	
	
}

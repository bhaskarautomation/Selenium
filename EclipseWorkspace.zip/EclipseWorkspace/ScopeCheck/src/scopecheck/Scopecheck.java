package scopecheck;

public class Scopecheck {

	public int publicvar = 0;
	private int privatevar = 1;
	
	//Constructor
	public Scopecheck() {
		
	}
     
	public int getPrivatevar() {
		return privatevar;
	}

   public void timestwo()
   {
	   int privatevar = 2;
	   for(int i=0;i<10;i++){
		   System.out.println(i+" times two is "+i*privatevar);
		   
	   }
	   //In the above method, the scope/visibility of variable "privatevar =2" is limited to timestwo.
	   //if the variable is not found in method timestwo,then java will take the privatevar =1 
	   
    }
	
	public class Innerclass{
		
		
		//private int privatevar = 3;

		public Innerclass() {
						
			System.out.println("Scopecheck created,privatevar = "+privatevar);	
		}

		  public void timestwo()
		   {
			  // int privatevar = 2;
			   for(int i=0;i<10;i++){
				   System.out.println(i +" times two is "+i*privatevar);
				   
			   }
			 
		    }
			
		
		
		
		
	}
	
}

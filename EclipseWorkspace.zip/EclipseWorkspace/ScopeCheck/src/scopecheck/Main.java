package scopecheck;

import scopecheck.Scopecheck.Innerclass;

public class Main {

	public static void main(String[] args) {
		String privatevar = "this is private to main()";
		Scopecheck a = new Scopecheck();
		System.out.println("ScopeInstance privatevar "+a.getPrivatevar());
		System.out.println(privatevar);
		a.timestwo();
		
		//Scope refers to the visibility of a class,member or variable.
		//Here the string privatevar = "this is private to main()" is limited to main method only.
		
		//There are two ways of instantiating the inner class.ONe is in line 19th and other is in line 20 th.
		//For line 19th,we need to instantiate the outerclass first as shown in line 9
		//Scopecheck.Innerclass b = a.new Innerclass();
		Scopecheck.Innerclass b = new Scopecheck().new Innerclass();
		b.timestwo();
	}

}

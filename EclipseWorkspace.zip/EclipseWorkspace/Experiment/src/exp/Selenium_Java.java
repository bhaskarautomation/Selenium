package exp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium_Java {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C://New folder//Java learning//Selenium//Drivers//chromedriver.exe");

		//WebDriver driver = new ChromeDriver();
		
		ChromeDriver driver = new ChromeDriver();
		
//		object.get("https://ui.freecrm.com/");
//		object.findElement(By.xpath("")).click();
		
//		WebDriver driver = (WebDriver)object;
		
		
		driver.manage().window().maximize();//Maximize the window
		driver.manage().deleteAllCookies();//Delete all cookies
		
		//dynamic wait
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		driver.get("https://ui.freecrm.com/");
		
		//driver.findElement(By.xpath("//input[@name='email']")).sendKeys("bhaskaraddanki@gmail.com");
//		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("bhaskar123");
//		
		WebElement loginbtn = driver.findElement(By.xpath("//div[@class='ui fluid large blue submit button']"));
//		
//		ClickusingJS(driver,loginbtn);
		
		driver.executeScript("arguments[0].click()",loginbtn);
		
	}
		
		
		


}

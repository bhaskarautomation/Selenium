package exp;

import java.util.Scanner;

public class stdin_and_stdout {

	static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = scan.nextInt();
        double d = scan.nextDouble();
        
        //Basically the function of nextline() is to place the cursor at next line explicitly(forcefully) otherwise the enter key press by us would be assigned in string ,ie string would remain blank.
        
        scan.nextLine(); 
        String s = scan.nextLine();
        
        
        //String s = scan.toString();
        

        System.out.println("String: " + s);
        System.out.println("Double: " + d);
        System.out.println("Int: " + i);
		
		
		
	}

}

package exp;

import java.util.ArrayList;
import java.util.Iterator;

public class Array {

	public static void main(String[] args) {


		int[] bha = new int[10];
		
		for (int i = 0; i < bha.length; i++) {
			
			bha[i]=i;
			System.out.println(bha[i]);
			
		}
		
		
		
		ArrayList<Integer> arraylist = new ArrayList<Integer>();
		
		arraylist.add(10);
		arraylist.add(2);
		arraylist.add(12);
		arraylist.add(3);
		 
	   for(int i=0;i<arraylist.size();i++)
	   {
	        System.out.println("Arraylist elements are "+arraylist.get(i));
	   }
		
		

	}

}

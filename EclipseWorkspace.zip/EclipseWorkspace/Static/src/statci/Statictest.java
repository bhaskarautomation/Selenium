package statci;

public class Statictest {
   private static int numInstance = 0;
   private String name;
   
   
public Statictest(String name) {
	this.name = name;
	numInstance++;
}


public String getName() {
	return name;
}


public int getNumInstance() {
	return numInstance;
}



   
   
	
	
}

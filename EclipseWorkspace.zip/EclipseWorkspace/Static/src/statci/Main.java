package statci;

public class Main {

	public static void main(String[] args) {
		
		Statictest firstinstance = new Statictest("1st Instance");
		
		System.out.println(firstinstance.getName()+" is instance number "+firstinstance.getNumInstance());
		
		Statictest secondinstance = new Statictest("2nd Instance");
		
		System.out.println(secondinstance.getName()+" is instance number "+secondinstance.getNumInstance());
		
		
	}

}

package practice;

class A {
		
	//parent constructor
	A(){
		
	System.out.println("This is super class constructor");
		
	}
	
	
	
	int a;
	
	public void methd(){
		
		System.out.println("This is parent class");
	}
	
}
		
class B extends A{
	
	//child constructor
	B(){
		
		System.out.println("This is sub class constructor");
		
	}
	
	
	int b;
	
	@Override
	
	public void methd(){
		
		super.methd();
		
		System.out.println("This is child class");
		
	}
	
}

public class practice2 {

	public static void main(String[] args) {
		
    B obj = new B();
    
//    obj.methd();
		
		
	}

}

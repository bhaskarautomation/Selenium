package practice;

class house{
	
	 String color;
	
		public house(String color){
			
			
		this.color = color;
		//coloooor = color;	
			
			System.out.println(color);
					
		}

		
	
	

}

//class villa extends house{
//
//	public villa(String color) {
//		
//		super(color);
//		System.out.println("hi");
//		System.out.println(color);
//		
//	}
//	
//}


public class practice3 {

	public static void main(String[] args) {
		
		house obj= new house("red"); //-Instantiation >> using new keyword, we are creating an object
		
		house obj1= new house("green");
		
//		villa obj1= new villa("Green");
		
		
	}

}

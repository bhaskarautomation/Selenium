package practice;

public class practice1 {

}

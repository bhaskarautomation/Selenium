package practice;

public class practice4 {

	public static void main(String[] args) {
		
	
		
		bhaskar();
	    bhaskar(2);
		

	}

	
	public static void bhaskar(){
		System.out.println("methd1");
		
		
	}
	
	public static void bhaskar(int a){
		
	System.out.println("method2");
	

	}
	
}

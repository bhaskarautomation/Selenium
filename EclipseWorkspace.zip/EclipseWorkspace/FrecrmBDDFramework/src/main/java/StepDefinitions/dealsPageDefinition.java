package StepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class dealsPageDefinition {
	WebDriver driver;
	
	@Given("^user is on Login page$")
	public void user_is_on_Login_page() throws InterruptedException 
	{

		System.setProperty("webdriver.chrome.driver", "C://New folder//Java learning//Selenium//Drivers//chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.freecrm.com/index.html");
        Thread.sleep(5);
		
	}
	
	@When("^user title of login Page is free crm$")
	public void user_title_of_login_Page_is_free_crm() {
		 String title= driver.getTitle();
		   System.out.println(title);
		   Assert.assertEquals("Free CRM #1 cloud software for any business large or small",title);
	}

	@Then("^user enter username and enter password$")
	public void user_enter_username_and_enter_password(DataTable cred) throws InterruptedException   {
	
	    List<List<String>> deals	= cred.raw();
		
		driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a")).click();
	    Thread.sleep(2);	     
		driver.findElement(By.name("email")).sendKeys(deals.get(0).get(0));
	    driver.findElement(By.name("password")).sendKeys(deals.get(0).get(1));
	     
		
	}
	
	@Then("user clicks on login button")
	public void user_clicks_on_login_button(){
		 driver.findElement(By.xpath("//*[@id='ui']/div/div/form/div/div[3]")).click();	
	}

	@Then("user is on Home Page")
	public void user_is_on_Home_Page(){
		 String title = driver.getTitle();
         System.out.println("Home Page title ::"+ title);
//		 Assert.assertEquals("CRMPRO", title);
		
	}
	
	@Then("^user moves to Deals page$")
	public void user_moves_to_Deals_page()  {
         driver.switchTo().frame("mainpanel");
         Actions action = new Actions(driver);
        
        action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Deals')]"))).build().perform();
        driver.findElement(By.xpath("//a[contains(text(),'New Deal')]")).click();
         
		 
	}

	@Then("^user enters the deal values$")
	public void user_enters_the_deal_values(DataTable arg1)  {
	    
	}

	@Then("^user close the browser$")
	public void user_close_the_browser()  {
	   driver.quit();
	}
	

}

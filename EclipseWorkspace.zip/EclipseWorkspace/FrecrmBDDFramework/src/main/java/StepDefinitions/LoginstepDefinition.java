package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginstepDefinition {
	
	
	
	
	WebDriver driver;
	
	@Given("^user is already on Login page$")
	public void user_is_already_on_Login_page() throws Throwable {
	   
		System.setProperty("webdriver.chrome.driver", "C://New folder//Java learning//Selenium//Drivers//chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.freecrm.com/index.html");
	
	}

	@When("^user title of login page is free crm$")
	public void user_title_of_login_page_is_free_crm() throws Throwable {
	   String title= driver.getTitle();
	   System.out.println(title);
	   Assert.assertEquals("Free CRM #1 cloud software for any business large or small",title);
	   
	}

	
	//Regular Exp:
	//1. \"([^\"]*)\"
	//2. \"(.*)\"
		
	
	@Then("^user enter \"([^\"]*)\" and enter \"([^\"]*)\"$")
	public void user_enter_username_and_enter_password(String username, String password) throws Throwable {
	     driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a")).click();
	     Thread.sleep(2);
	     
		 driver.findElement(By.name("email")).sendKeys(username);
	     driver.findElement(By.name("password")).sendKeys(password);
	     
		
		
	}

	@Then("^user clicks on Login button$")
	public void user_clicks_on_Login_button() throws Throwable {
	   driver.findElement(By.xpath("//*[@id='ui']/div/div/form/div/div[3]")).click();
	
	}

	@Then("^user is on Home page$")
	public void user_is_on_Home_page() throws Throwable {

		
	}


	
	

}

package MyRunner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//@Runwith(Cucumber.options)

/*
@CucumberOptions(
   features = the path of the feature files
   glue=the path of the step definition files
   format= to generate different types of reporting
   monochrome = display the console output in a proper readable format
   strict = it will check if any step is not defined in step definition file
   dryRun = to check the mapping is proper between feature file and step def file
   )
*/

  @RunWith(Cucumber.class)
  @CucumberOptions(
		  
		  features = "C:\\Users\\AG18664\\EclipseWorkspace\\FrecrmBDDFramework\\src\\main\\java\\Features\\dealspage.feature",
		  glue= {"StepDefinitions"},
		  format = {"pretty","html:test-output","json:json_output/cucumber.json","junit:junit_xml/cucumber.xml"},
		  monochrome = true,
		  strict= true,
		  dryRun = false
		  )

public class Testrunner {

}


  
  
  
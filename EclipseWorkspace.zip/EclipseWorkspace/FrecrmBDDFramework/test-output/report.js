$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/AG18664/EclipseWorkspace/FrecrmBDDFramework/src/main/java/Features/dealspage.feature");
formatter.feature({
  "line": 1,
  "name": "create deals on deals page",
  "description": "",
  "id": "create-deals-on-deals-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "deals page scenario",
  "description": "",
  "id": "create-deals-on-deals-page;deals-page-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "user is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user title of login Page is free crm",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "user enter username and enter password",
  "rows": [
    {
      "cells": [
        "abrao1992@gmail.com",
        "Hola#123"
      ],
      "line": 9
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user clicks on login button",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "user is on Home Page",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "user moves to Deals page",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "user enters the deal values",
  "rows": [
    {
      "cells": [
        "deal1",
        "100",
        "200",
        "300"
      ],
      "line": 14
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "user close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "dealsPageDefinition.user_is_on_Login_page()"
});
formatter.result({
  "duration": 303715517459,
  "error_message": "org.openqa.selenium.TimeoutException: timeout\n  (Session info: chrome\u003d78.0.3904.108)\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027L4D9Q8S2\u0027, ip: \u002730.239.53.27\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d78.0.3904.105 (60e2d8774a8151efa6a00b1f358371b1e0e07ee2-refs/branch-heads/3904@{#877}), userDataDir\u003dC:\\Users\\AG18664\\AppData\\Local\\Temp\\1\\scoped_dir1772_1313958331}, timeouts\u003d{implicit\u003d0, pageLoad\u003d300000, script\u003d30000}, pageLoadStrategy\u003dnormal, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dWIN8_1, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:52811}, acceptInsecureCerts\u003dfalse, browserVersion\u003d78.0.3904.108, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dWIN8_1, setWindowRect\u003dtrue}]\nSession ID: 0888eef0f37d5f1934c7ae8e762728c9\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:185)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:120)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:646)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.get(RemoteWebDriver.java:370)\r\n\tat StepDefinitions.dealsPageDefinition.user_is_on_Login_page(dealsPageDefinition.java:25)\r\n\tat ✽.Given user is on Login page(C:/Users/AG18664/EclipseWorkspace/FrecrmBDDFramework/src/main/java/Features/dealspage.feature:6)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "dealsPageDefinition.user_title_of_login_Page_is_free_crm()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_enter_username_and_enter_password(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_clicks_on_login_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_is_on_Home_Page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_moves_to_Deals_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_enters_the_deal_values(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "dealsPageDefinition.user_close_the_browser()"
});
formatter.result({
  "status": "skipped"
});
});
package Final;

public class main {

	public static void main(String[] args) {

		Someclass one = new Someclass("one");
        Someclass two = new Someclass("two");
        Someclass three = new Someclass("three");

        System.out.println(one.getInstanceNumber());
        System.out.println(two.getInstanceNumber());
        System.out.println(three.getInstanceNumber());

        System.out.println(Math.PI);
      
        
	}

	
	 
}

package hasmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class LinkedHashmap {

	public static void main(String[] args) {
		
		//Hashmap,LinkedHashmap and TreeMap implements the interface Map
		
		Map<Integer, String> hmap = new HashMap<Integer, String>();
		
		//Hashmap will NOT sort the keys and values of map in any order.However sometimes it does and sometimes it doesn't.
		//Hashmap is not reliable for sorting the keys an values in map
		
		Map<Integer, String> linkedhmap = new LinkedHashMap<Integer, String>();
		
		//LinkedHashmap :the keys and values will stay in the order you add them to the map.
		
		Map<Integer, String> treemap = new TreeMap<Integer, String>();
		
		/* Tree is kind of basic structures in computing
		 * Tree sorts the keys in natural order.Natural order means for integers,it is 0,1,2..
		 * and for String,natural order is in aplhabetical order a,b,c..
		 * If you want to pass them to a method ,you can just type Map<> as argument type
		 */
	
		testMap(treemap);
		
	}

	public static void testMap(Map<Integer, String> map)
	{
		map.put(9, "bear");
		map.put(4, "fox");
		map.put(8, "dog");
		map.put(0, "horse");
		map.put(1, "swan");
		map.put(15, "donkey");
		map.put(6, "snake");
		
		for(Integer key: map.keySet())//map.keySet() returns set of keys.it actually returns collection called a set.
		{
			
		  String value = map.get(key);
		  System.out.println(key + " : "+ value);
			
		}
		
		
		
	}
}

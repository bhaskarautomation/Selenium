package hasmap;

import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		
		
		Map <Integer,String> map = new HashMap <Integer,String>();
		
		map.put(1, "One");
		
		map.put(5, "Five");
		
		map.put(7, "Seven");
		
		map.put(2, "Two");
		
		String text = map.get(7);
		
		System.out.println(text);
		
		for(Map.Entry<Integer,String> entry:map.entrySet()){
			
			int key = entry.getKey();
			String value = entry.getValue();
			System.out.println(key + ":"+value);
		}
		
		
	}

}

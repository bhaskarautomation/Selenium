package project;

public interface Itelephone {
	
	void powerOn();
	void dail(int phoneNumber);
	void answer();
	boolean callPhone(int phoneNumber);
	boolean isRinging();
	
	

}

package project;

public class Main {

	public static void main(String[] args) {
	
		Itelephone bossphone;
		
		bossphone = new Deskphone(123456);
		bossphone.callPhone(123456);
		bossphone.answer();
		
		System.out.println("Mobile phone");
		
		bossphone = new Mobilephone(12345);
		bossphone.powerOn();
		bossphone.callPhone(12345);
		bossphone.answer();
		
		//We instantiated the two class Deskphone and Mobilephone using the same name "bossname"
		//because Deskphone and Mobilephone implements the same interface "Itelephone".Otherwise we should have
		//instantiated the both class with different names in the below manner
//		Deskphone bossname =new Deskphone(123456);
//		Mobilephone bossname1 =new Mobilephone(123456);
		
		
	}

}

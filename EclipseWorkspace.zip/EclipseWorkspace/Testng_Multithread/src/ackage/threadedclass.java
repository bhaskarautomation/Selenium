package ackage;

import org.testng.annotations.Test;

public class threadedclass {

	
	@Test(threadPoolSize = 3,invocationCount =3,timeOut =1000)
	public void Method1()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is Method1 and id is "+ id);
	}
}

package ackage;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class multithread {

	
	@BeforeMethod
	public void beforeMethod()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is before method and id is "+ id);
	}
	
	@Test
	public void Method1()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is Method1 and id is "+ id);
	}
	
	@Test
	public void Method2()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is Method2 and id is "+ id);
	}
	
	@Test
	public void Method3()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is Method3 and id is "+ id);
	}
	
	@org.testng.annotations.AfterMethod
	public void AfterMethod()
	{
		long id = Thread.currentThread().getId();
		
		System.out.println("This is after method and id is "+ id);
	}
}
